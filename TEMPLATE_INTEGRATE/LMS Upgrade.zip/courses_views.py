import uuid, json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy, reverse
from django.db.models import Q, Count
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import (
    Course, Module, Lesson, LessonFile, Enrollment,
    LessonCompletion, Subject, CourseCompletionCertificate
)
from .forms import CourseForm, ModuleForm, LessonForm, LessonFileForm


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────

def _is_enrolled_active(user, course):
    return Enrollment.objects.filter(
        student=user, course=course, status='active'
    ).exists()


def _maybe_issue_certificate(student, course):
    cert, created = CourseCompletionCertificate.objects.get_or_create(
        student=student,
        course=course,
        defaults={'certificate_number': uuid.uuid4().hex.upper()}
    )
    if created:
        _notify(
            student,
            f'You earned a certificate for completing {course.title}!',
            'certificate',
            link=reverse('courses:certificate', kwargs={'pk': cert.pk})
        )
    return cert if created else None


def _notify(user, message, notif_type, link=''):
    try:
        from notifications.models import Notification
        Notification.objects.create(
            recipient=user, message=message,
            notif_type=notif_type, link=link,
        )
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────
# Mixins
# ──────────────────────────────────────────────────────────────

class TeacherRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_teacher or self.request.user.is_school_admin


class CourseOwnerMixin(UserPassesTestMixin):
    def get_course(self):
        raise NotImplementedError

    def test_func(self):
        user = self.request.user
        if user.is_school_admin:
            return True
        return user.is_teacher and self.get_course().teacher == user


# ──────────────────────────────────────────────────────────────
# Course discovery
# ──────────────────────────────────────────────────────────────

class CourseListView(LoginRequiredMixin, ListView):
    model = Course
    template_name = 'courses/course_list.html'
    context_object_name = 'courses'
    paginate_by = 12

    def get_queryset(self):
        user = self.request.user
        if user.is_student:
            ids = Enrollment.objects.filter(
                student=user, status='active'
            ).values_list('course_id', flat=True)
            qs = Course.objects.filter(is_active=True, id__in=ids)
        elif user.is_teacher:
            qs = Course.objects.filter(is_active=True, teacher=user)
        else:
            qs = Course.objects.filter(is_active=True)
        search = self.request.GET.get('search')
        if search:
            qs = qs.filter(
                Q(title__icontains=search) | Q(code__icontains=search) |
                Q(description__icontains=search)
            )
        if s := self.request.GET.get('subject'):
            qs = qs.filter(subject_id=s)
        if g := self.request.GET.get('grade'):
            qs = qs.filter(grade_level=g)
        return qs.select_related('teacher', 'subject').prefetch_related('students')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['subjects'] = Subject.objects.all()
        ctx['grade_levels'] = range(9, 13)
        ctx['is_student'] = self.request.user.is_student
        if self.request.user.is_teacher:
            ctx['pending_count'] = Enrollment.objects.filter(
                course__teacher=self.request.user, status='pending'
            ).count()
        return ctx


class CourseBrowseView(LoginRequiredMixin, ListView):
    model = Course
    template_name = 'courses/course_browse.html'
    context_object_name = 'courses'
    paginate_by = 12

    def get_queryset(self):
        qs = Course.objects.filter(is_active=True)
        if search := self.request.GET.get('search'):
            qs = qs.filter(
                Q(title__icontains=search) | Q(code__icontains=search) |
                Q(description__icontains=search)
            )
        if s := self.request.GET.get('subject'):
            qs = qs.filter(subject_id=s)
        if g := self.request.GET.get('grade'):
            qs = qs.filter(grade_level=g)
        return qs.select_related('teacher', 'subject')

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['subjects'] = Subject.objects.all()
        ctx['grade_levels'] = range(9, 13)
        if self.request.user.is_student:
            ctx['enrolled_ids'] = set(
                Enrollment.objects.filter(
                    student=self.request.user,
                    status__in=['active', 'pending']
                ).values_list('course_id', flat=True)
            )
        return ctx


# ──────────────────────────────────────────────────────────────
# Course detail
# ──────────────────────────────────────────────────────────────

class CourseDetailView(LoginRequiredMixin, DetailView):
    model = Course
    template_name = 'courses/course_detail.html'
    context_object_name = 'course'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        course = self.object
        user = self.request.user

        if user.is_student:
            enrollment = Enrollment.objects.filter(
                student=user, course=course
            ).first()
            ctx['enrollment'] = enrollment
            ctx['is_enrolled'] = bool(enrollment and enrollment.status == 'active')
            ctx['is_pending'] = bool(enrollment and enrollment.status == 'pending')

            if ctx['is_enrolled']:
                total = Lesson.objects.filter(
                    module__course=course, is_published=True
                ).count()
                completed_ids = set(
                    LessonCompletion.objects.filter(
                        student=user, lesson__module__course=course
                    ).values_list('lesson_id', flat=True)
                )
                ctx['completed_ids'] = completed_ids
                ctx['total_lessons'] = total
                ctx['completed_lessons'] = len(completed_ids)
                ctx['progress_percentage'] = round(
                    (len(completed_ids) / total * 100) if total > 0 else 0, 1
                )
                # Lesson accessibility map
                lessons = Lesson.objects.filter(
                    module__course=course, is_published=True
                ).select_related('prerequisite')
                ctx['lesson_access'] = {l.pk: l.is_accessible_to(user) for l in lessons}

                # Auto-issue certificate
                if total > 0 and len(completed_ids) == total:
                    _maybe_issue_certificate(user, course)
                    ctx['certificate'] = CourseCompletionCertificate.objects.filter(
                        student=user, course=course
                    ).first()

        elif user.is_teacher and course.teacher == user or user.is_school_admin:
            roster = Enrollment.objects.filter(
                course=course
            ).select_related('student').order_by('status', 'student__last_name')
            ctx['pending_enrollments'] = roster.filter(status='pending')
            ctx['active_count'] = roster.filter(status='active').count()

        ctx['modules'] = course.modules.prefetch_related(
            'lessons', 'lessons__files', 'lessons__prerequisite'
        ).order_by('order')
        return ctx


# ──────────────────────────────────────────────────────────────
# Enrolment
# ──────────────────────────────────────────────────────────────

@login_required
@require_POST
def enroll_course(request, pk):
    course = get_object_or_404(Course, pk=pk, is_active=True)
    if not request.user.is_student:
        messages.error(request, 'Only students can enrol.')
        return redirect('courses:detail', pk=pk)
    if not course.enrolment_is_open:
        messages.error(request, 'Enrolment is not currently open.')
        return redirect('courses:detail', pk=pk)
    if course.enrolment_type == 'invite':
        messages.error(request, 'This course is invite-only.')
        return redirect('courses:detail', pk=pk)
    if course.is_full:
        messages.error(request, 'This course is full.')
        return redirect('courses:detail', pk=pk)

    initial_status = 'pending' if course.enrolment_type == 'approval' else 'active'
    enrollment, created = Enrollment.objects.get_or_create(
        student=request.user, course=course,
        defaults={'status': initial_status}
    )

    if not created and enrollment.status == 'dropped':
        enrollment.status = initial_status
        enrollment.save()
        created = True

    if created:
        if initial_status == 'active':
            course.students.add(request.user)
            messages.success(request, f'Enrolled in {course.title}!')
            _notify(request.user, f'You are now enrolled in {course.title}.', 'enrolment')
        else:
            messages.info(request, 'Your enrolment request is pending approval.')
            _notify(
                course.teacher,
                f'{request.user.get_full_name()} wants to join {course.title}.',
                'enrolment_request',
                link=reverse('courses:enrolment_requests', kwargs={'pk': course.pk})
            )
    elif enrollment.status == 'pending':
        messages.info(request, 'Your request is already pending.')
    else:
        messages.info(request, 'You are already enrolled.')
    return redirect('courses:detail', pk=pk)


@login_required
@require_POST
def unenroll_course(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if not request.user.is_student:
        messages.error(request, 'Invalid action.')
        return redirect('courses:detail', pk=pk)
    try:
        enr = Enrollment.objects.get(student=request.user, course=course)
        enr.status = 'dropped'
        enr.save()
        course.students.remove(request.user)
        messages.success(request, f'Unenrolled from {course.title}.')
    except Enrollment.DoesNotExist:
        messages.error(request, 'You are not enrolled.')
    return redirect('courses:list')


@login_required
def enrolment_requests(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:detail', pk=pk)
    pending = Enrollment.objects.filter(
        course=course, status='pending'
    ).select_related('student')
    return render(request, 'courses/enrolment_requests.html', {
        'course': course, 'pending': pending,
    })


@login_required
@require_POST
def approve_enrolment(request, enrollment_pk):
    enr = get_object_or_404(Enrollment, pk=enrollment_pk)
    course = enr.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:detail', pk=course.pk)
    enr.status = 'active'
    enr.reviewed_by = request.user
    enr.reviewed_at = timezone.now()
    enr.save()
    course.students.add(enr.student)
    _notify(
        enr.student,
        f'Your enrolment in {course.title} has been approved!',
        'enrolment_approved',
        link=reverse('courses:detail', kwargs={'pk': course.pk})
    )
    messages.success(request, f'{enr.student.get_full_name()} approved.')
    return redirect('courses:enrolment_requests', pk=course.pk)


@login_required
@require_POST
def reject_enrolment(request, enrollment_pk):
    enr = get_object_or_404(Enrollment, pk=enrollment_pk)
    course = enr.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:detail', pk=course.pk)
    enr.status = 'rejected'
    enr.reviewed_by = request.user
    enr.reviewed_at = timezone.now()
    enr.rejection_reason = request.POST.get('reason', '')
    enr.save()
    _notify(enr.student, f'Your enrolment in {course.title} was not approved.', 'enrolment_rejected')
    messages.info(request, f'{enr.student.get_full_name()} rejected.')
    return redirect('courses:enrolment_requests', pk=course.pk)


# ──────────────────────────────────────────────────────────────
# Student roster
# ──────────────────────────────────────────────────────────────

@login_required
def student_roster(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:detail', pk=pk)

    enrollments = Enrollment.objects.filter(
        course=course
    ).select_related('student').order_by('status', 'student__last_name')

    total_lessons = Lesson.objects.filter(
        module__course=course, is_published=True
    ).count()

    per_student = {
        row['student_id']: row['cnt']
        for row in LessonCompletion.objects.filter(
            lesson__module__course=course
        ).values('student_id').annotate(cnt=Count('id'))
    }

    roster_data = [{
        'enrollment': enr,
        'completed': per_student.get(enr.student_id, 0),
        'total': total_lessons,
        'pct': round(
            (per_student.get(enr.student_id, 0) / total_lessons * 100)
            if total_lessons > 0 else 0, 1
        ),
    } for enr in enrollments]

    return render(request, 'courses/student_roster.html', {
        'course': course,
        'roster_data': roster_data,
        'total_lessons': total_lessons,
    })


# ──────────────────────────────────────────────────────────────
# Lessons
# ──────────────────────────────────────────────────────────────

class LessonDetailView(LoginRequiredMixin, DetailView):
    model = Lesson
    template_name = 'courses/lesson_detail.html'
    context_object_name = 'lesson'

    def dispatch(self, request, *args, **kwargs):
        resp = super().dispatch(request, *args, **kwargs)
        if request.user.is_authenticated:
            lesson = self.get_object()
            course = lesson.module.course
            user = request.user
            is_enrolled = _is_enrolled_active(user, course)
            allowed = (
                user.is_school_admin or course.teacher == user or
                (user.is_student and is_enrolled)
            )
            if not allowed:
                messages.error(request, 'You do not have access to this lesson.')
                return redirect('courses:detail', pk=course.pk)
            if user.is_student and is_enrolled and not lesson.is_accessible_to(user):
                messages.warning(
                    request,
                    f'Complete "{lesson.prerequisite.title}" before accessing this lesson.'
                )
                return redirect('courses:detail', pk=course.pk)
        return resp

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        lesson = self.object
        user = self.request.user
        if user.is_student:
            ctx['is_completed'] = LessonCompletion.objects.filter(
                student=user, lesson=lesson
            ).exists()
        siblings = list(
            Lesson.objects.filter(
                module=lesson.module, is_published=True
            ).order_by('order')
        )
        idx = next((i for i, l in enumerate(siblings) if l.pk == lesson.pk), None)
        if idx is not None:
            ctx['prev_lesson'] = siblings[idx - 1] if idx > 0 else None
            ctx['next_lesson'] = siblings[idx + 1] if idx < len(siblings) - 1 else None
        ctx['files'] = lesson.files.all()
        return ctx


@login_required
@require_POST
def complete_lesson(request, pk):
    lesson = get_object_or_404(Lesson, pk=pk)
    if not request.user.is_student:
        messages.error(request, 'Invalid action.')
        return redirect('courses:lesson_detail', pk=pk)
    course = lesson.module.course
    if not _is_enrolled_active(request.user, course):
        messages.error(request, 'You must be enrolled.')
        return redirect('courses:detail', pk=course.pk)
    if not lesson.is_accessible_to(request.user):
        messages.error(request, 'Complete the prerequisite lesson first.')
        return redirect('courses:lesson_detail', pk=pk)

    time_spent = int(request.POST.get('time_spent', 0))
    _, created = LessonCompletion.objects.get_or_create(
        student=request.user, lesson=lesson,
        defaults={'time_spent_minutes': time_spent}
    )
    if created:
        messages.success(request, f'"{lesson.title}" marked as complete!')
        total = Lesson.objects.filter(
            module__course=course, is_published=True
        ).count()
        completed = LessonCompletion.objects.filter(
            student=request.user, lesson__module__course=course
        ).count()
        if total > 0 and completed == total:
            cert = _maybe_issue_certificate(request.user, course)
            if cert:
                messages.success(
                    request,
                    f'You completed {course.title}! Your certificate is ready.'
                )
    else:
        messages.info(request, 'Already marked as complete.')
    return redirect('courses:lesson_detail', pk=pk)


@login_required
@require_POST
def toggle_lesson_publish(request, pk):
    lesson = get_object_or_404(Lesson, pk=pk)
    course = lesson.module.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        return JsonResponse({'error': 'Permission denied'}, status=403)
    lesson.is_published = not lesson.is_published
    lesson.save(update_fields=['is_published'])
    return JsonResponse({'is_published': lesson.is_published})


@login_required
@require_POST
def reorder_modules(request, course_pk):
    course = get_object_or_404(Course, pk=course_pk)
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        return JsonResponse({'error': 'Permission denied'}, status=403)
    for item in json.loads(request.body):
        Module.objects.filter(pk=item['id'], course=course).update(order=item['order'])
    return JsonResponse({'status': 'ok'})


@login_required
@require_POST
def reorder_lessons(request, module_pk):
    module = get_object_or_404(Module, pk=module_pk)
    course = module.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        return JsonResponse({'error': 'Permission denied'}, status=403)
    for item in json.loads(request.body):
        Lesson.objects.filter(pk=item['id'], module=module).update(order=item['order'])
    return JsonResponse({'status': 'ok'})


# ──────────────────────────────────────────────────────────────
# Course CRUD
# ──────────────────────────────────────────────────────────────

class CourseCreateView(LoginRequiredMixin, TeacherRequiredMixin, CreateView):
    model = Course
    form_class = CourseForm
    template_name = 'courses/course_form.html'
    success_url = reverse_lazy('courses:list')

    def form_valid(self, form):
        form.instance.teacher = self.request.user
        messages.success(self.request, 'Course created!')
        return super().form_valid(form)


class CourseUpdateView(LoginRequiredMixin, CourseOwnerMixin, UpdateView):
    model = Course
    form_class = CourseForm
    template_name = 'courses/course_form.html'

    def get_course(self):
        return self.get_object()

    def form_valid(self, form):
        messages.success(self.request, 'Course updated!')
        return super().form_valid(form)


class CourseDeleteView(LoginRequiredMixin, CourseOwnerMixin, DeleteView):
    model = Course
    template_name = 'courses/course_confirm_delete.html'
    success_url = reverse_lazy('courses:list')

    def get_course(self):
        return self.get_object()

    def form_valid(self, form):
        messages.success(self.request, 'Course deleted.')
        return super().form_valid(form)


@login_required
def duplicate_course(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:detail', pk=pk)

    if request.method != 'POST':
        return render(request, 'courses/course_duplicate_confirm.html', {'course': course})

    new_year = int(request.POST.get('year', course.year))
    new_term = request.POST.get('term', course.term)
    new_code = f"{course.code}-{new_year}{new_term or ''}"[:20]

    new_course = Course.objects.create(
        title=f"{course.title} (copy)",
        code=new_code,
        subject=course.subject,
        description=course.description,
        teacher=request.user,
        grade_level=course.grade_level,
        term=new_term,
        year=new_year,
        max_students=course.max_students,
        enrolment_type=course.enrolment_type,
        is_active=False,
    )
    for module in course.modules.prefetch_related('lessons').order_by('order'):
        new_mod = Module.objects.create(
            course=new_course, title=module.title,
            description=module.description, order=module.order,
        )
        for lesson in module.lessons.order_by('order'):
            Lesson.objects.create(
                module=new_mod, title=lesson.title,
                content=lesson.content, video_url=lesson.video_url,
                order=lesson.order, duration_minutes=lesson.duration_minutes,
                is_published=False,
            )
    messages.success(request, f'Course duplicated as "{new_course.title}" (inactive draft).')
    return redirect('courses:update', pk=new_course.pk)


# ──────────────────────────────────────────────────────────────
# Module CRUD
# ──────────────────────────────────────────────────────────────

class ModuleCreateView(LoginRequiredMixin, CourseOwnerMixin, CreateView):
    model = Module
    form_class = ModuleForm
    template_name = 'courses/module_form.html'

    def get_course(self):
        return get_object_or_404(Course, pk=self.kwargs['course_pk'])

    def form_valid(self, form):
        form.instance.course = self.get_course()
        messages.success(self.request, 'Module created.')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('courses:detail', kwargs={'pk': self.kwargs['course_pk']})


class ModuleUpdateView(LoginRequiredMixin, CourseOwnerMixin, UpdateView):
    model = Module
    form_class = ModuleForm
    template_name = 'courses/module_form.html'

    def get_course(self):
        return self.get_object().course

    def get_success_url(self):
        return reverse_lazy('courses:detail', kwargs={'pk': self.object.course.pk})


class ModuleDeleteView(LoginRequiredMixin, CourseOwnerMixin, DeleteView):
    model = Module
    template_name = 'courses/module_confirm_delete.html'

    def get_course(self):
        return self.get_object().course

    def get_success_url(self):
        return reverse_lazy('courses:detail', kwargs={'pk': self.object.course.pk})

    def form_valid(self, form):
        messages.success(self.request, 'Module deleted.')
        return super().form_valid(form)


# ──────────────────────────────────────────────────────────────
# Lesson CRUD
# ──────────────────────────────────────────────────────────────

class LessonCreateView(LoginRequiredMixin, CourseOwnerMixin, CreateView):
    model = Lesson
    form_class = LessonForm
    template_name = 'courses/lesson_form.html'

    def get_course(self):
        return get_object_or_404(Module, pk=self.kwargs['module_pk']).course

    def form_valid(self, form):
        form.instance.module = get_object_or_404(Module, pk=self.kwargs['module_pk'])
        messages.success(self.request, 'Lesson created.')
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('courses:detail', kwargs={'pk': self.object.module.course.pk})


class LessonUpdateView(LoginRequiredMixin, CourseOwnerMixin, UpdateView):
    model = Lesson
    form_class = LessonForm
    template_name = 'courses/lesson_form.html'

    def get_course(self):
        return self.get_object().module.course

    def get_success_url(self):
        return reverse_lazy('courses:lesson_detail', kwargs={'pk': self.object.pk})


class LessonDeleteView(LoginRequiredMixin, CourseOwnerMixin, DeleteView):
    model = Lesson
    template_name = 'courses/lesson_confirm_delete.html'

    def get_course(self):
        return self.get_object().module.course

    def get_success_url(self):
        return reverse_lazy('courses:detail', kwargs={'pk': self.object.module.course.pk})

    def form_valid(self, form):
        messages.success(self.request, 'Lesson deleted.')
        return super().form_valid(form)


# ──────────────────────────────────────────────────────────────
# Lesson file attachments
# ──────────────────────────────────────────────────────────────

@login_required
def upload_lesson_file(request, lesson_pk):
    lesson = get_object_or_404(Lesson, pk=lesson_pk)
    course = lesson.module.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:lesson_detail', pk=lesson_pk)
    if request.method == 'POST':
        form = LessonFileForm(request.POST, request.FILES)
        if form.is_valid():
            lf = form.save(commit=False)
            lf.lesson = lesson
            lf.save()
            messages.success(request, 'File uploaded.')
            return redirect('courses:lesson_detail', pk=lesson_pk)
    else:
        form = LessonFileForm()
    return render(request, 'courses/lesson_file_form.html', {'form': form, 'lesson': lesson})


@login_required
@require_POST
def delete_lesson_file(request, pk):
    lf = get_object_or_404(LessonFile, pk=pk)
    course = lf.lesson.module.course
    if not ((request.user.is_teacher and course.teacher == request.user)
            or request.user.is_school_admin):
        messages.error(request, 'Permission denied.')
        return redirect('courses:lesson_detail', pk=lf.lesson.pk)
    lesson_pk = lf.lesson.pk
    lf.file.delete(save=False)
    lf.delete()
    messages.success(request, 'File deleted.')
    return redirect('courses:lesson_detail', pk=lesson_pk)


# ──────────────────────────────────────────────────────────────
# Certificates
# ──────────────────────────────────────────────────────────────

@login_required
def view_certificate(request, pk):
    cert = get_object_or_404(
        CourseCompletionCertificate, pk=pk, student=request.user
    )
    return render(request, 'courses/certificate.html', {'cert': cert})


@login_required
def my_certificates(request):
    certs = CourseCompletionCertificate.objects.filter(
        student=request.user
    ).select_related('course')
    return render(request, 'courses/my_certificates.html', {'certs': certs})
