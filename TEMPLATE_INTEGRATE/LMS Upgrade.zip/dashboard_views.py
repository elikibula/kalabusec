from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Avg, Max, Min
from django.utils import timezone

from courses.models import Course, Enrollment, LessonCompletion, Lesson, CourseCompletionCertificate
from assignments.models import Assignment, Submission
from announcements.models import Announcement


@login_required
def home(request):
    user = request.user
    context = {}

    if user.is_student:
        enrolled_ids = Enrollment.objects.filter(
            student=user, status='active'
        ).values_list('course_id', flat=True)
        enrolled_courses = Course.objects.filter(
            id__in=enrolled_ids, is_active=True
        ).select_related('teacher', 'subject')
        context['enrolled_courses'] = enrolled_courses[:6]

        context['upcoming_assignments'] = (
            Assignment.objects
            .filter(course__in=enrolled_courses, due_date__gte=timezone.now())
            .select_related('course').order_by('due_date')[:5]
        )
        context['recent_submissions'] = (
            Submission.objects.filter(student=user)
            .select_related('assignment', 'assignment__course')
            .order_by('-submitted_at')[:5]
        )

        lesson_totals = {
            row['module__course_id']: row['total']
            for row in Lesson.objects.filter(
                module__course__in=enrolled_courses, is_published=True
            ).values('module__course_id').annotate(total=Count('id'))
        }
        completion_counts = {
            row['lesson__module__course_id']: row['cnt']
            for row in LessonCompletion.objects.filter(
                student=user, lesson__module__course__in=enrolled_courses
            ).values('lesson__module__course_id').annotate(cnt=Count('id'))
        }
        context['progress_data'] = [{
            'course': c,
            'total': lesson_totals.get(c.pk, 0),
            'completed': completion_counts.get(c.pk, 0),
            'percentage': round(
                (completion_counts.get(c.pk, 0) / lesson_totals[c.pk] * 100)
                if lesson_totals.get(c.pk, 0) > 0 else 0, 1
            ),
        } for c in enrolled_courses]

        context['certificates'] = CourseCompletionCertificate.objects.filter(
            student=user
        ).select_related('course')[:3]
        context['pending_enrollments'] = Enrollment.objects.filter(
            student=user, status='pending'
        ).select_related('course')

    if user.is_teacher:
        teaching_courses = Course.objects.filter(
            teacher=user, is_active=True
        ).annotate(student_count=Count('students', distinct=True))
        context['teaching_courses'] = teaching_courses
        context['pending_submissions'] = (
            Submission.objects
            .filter(assignment__course__teacher=user, status='submitted')
            .select_related('student', 'assignment', 'assignment__course')
            .order_by('-submitted_at')[:10]
        )
        context['pending_enrolments'] = Enrollment.objects.filter(
            course__teacher=user, status='pending'
        ).select_related('student', 'course')[:5]
        context['course_stats'] = [{
            'course': c,
            'students': c.student_count,
            'assignments': c.assignments.count(),
        } for c in teaching_courses]

    if user.is_school_admin:
        context['total_courses'] = Course.objects.filter(is_active=True).count()
        context['total_students'] = user.__class__.objects.filter(role='student').count()
        context['total_teachers'] = user.__class__.objects.filter(role='teacher').count()
        context['recent_enrollments'] = Enrollment.objects.select_related(
            'student', 'course'
        ).order_by('-enrolled_at')[:10]

    context['recent_announcements'] = Announcement.objects.filter(
        is_published=True, published_date__lte=timezone.now()
    ).select_related('author').order_by('-published_date')[:5]

    try:
        from notifications.models import Notification
        context['unread_notifications'] = Notification.objects.filter(
            recipient=user, is_read=False
        ).count()
    except Exception:
        context['unread_notifications'] = 0

    return render(request, 'dashboard/home.html', context)


@login_required
def analytics(request):
    user = request.user
    context = {}

    if user.is_student:
        enrollments = Enrollment.objects.filter(student=user)
        context.update(enrollments.exclude(final_grade__isnull=True).aggregate(
            average=Avg('final_grade'),
            highest=Max('final_grade'),
            lowest=Min('final_grade'),
        ))
        submissions = Submission.objects.filter(student=user)
        context['total_submissions'] = submissions.count()
        context['graded_submissions'] = submissions.filter(status='graded').count()
        context['completed_lessons'] = LessonCompletion.objects.filter(student=user).count()
        context['certificates'] = CourseCompletionCertificate.objects.filter(
            student=user
        ).select_related('course')

    elif user.is_teacher:
        courses = Course.objects.filter(teacher=user)
        context['total_courses'] = courses.count()
        context['total_students'] = courses.aggregate(
            total=Count('students', distinct=True)
        )['total'] or 0
        context['total_assignments'] = Assignment.objects.filter(course__teacher=user).count()
        submissions = Submission.objects.filter(assignment__course__teacher=user)
        context['total_submissions'] = submissions.count()
        context['pending_grading'] = submissions.filter(status='submitted').count()

    elif user.is_school_admin:
        context['total_courses'] = Course.objects.filter(is_active=True).count()
        context['total_students'] = user.__class__.objects.filter(role='student').count()
        context['total_teachers'] = user.__class__.objects.filter(role='teacher').count()
        context['total_submissions'] = Submission.objects.count()
        context['pending_grading'] = Submission.objects.filter(status='submitted').count()

    return render(request, 'dashboard/analytics.html', context)
